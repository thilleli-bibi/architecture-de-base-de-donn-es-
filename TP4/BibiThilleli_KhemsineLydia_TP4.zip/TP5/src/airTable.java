
/**
 * TP n°:4
 * 
 * Titre du TP :block nestedloop join
 *
 * Date : 19/11/2020
 * 
 * Nom  : Bibi
 * Prenom : Thilleli
 *
 * email : thillelibibi@gmail.com
 * 
 * Remarques : binome : lydia khemsine 
 *            email : lydiakhemsine@outlook.com
 *           
 *           lien vers airtable : https://airtable.com/shrVJ85vp083bMJVv
 */
import java.io.IOException;
import java.lang.reflect.Array;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class airTable {
	private static final HttpClient httpClient = HttpClient.newBuilder()
			.version(HttpClient.Version.HTTP_1_1)
			.build();
	
	public static void block_to_airtable(int[] block,String blockname) throws IOException, InterruptedException {
		
		StringBuilder json = new StringBuilder() ;
		json.append("{ \"records\": [");

			for (int i=0;i < 9; i++) {
				json.append(" { \"fields\": { \"Name\":\""  + block[i] + "\" }},").toString();
			}
			json.append(" { \"fields\": { \"Name\":\""  + block[9] + "\"}}").toString();
			json.append("]}");
			
			String jsonString = json.toString() ;

			HttpResponse response;

			// add json header
			HttpRequest request = HttpRequest.newBuilder()
							.POST(HttpRequest.BodyPublishers.ofString(jsonString))
							.uri(URI.create(blockname))
							.setHeader("User-Agent", "Java 11 HttpClient Bot") // add request header
							.header("Content-Type", "application/json")
							.build();
			response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
			System.out.println(response);
			System.out.println(response.body());
			
	}    
	
	
	
	
	public static void tabledescriptor(String[] table,String tablename) throws IOException, InterruptedException {
		 int i;
		StringBuilder json = new StringBuilder() ;
		json.append("{ \"records\": [");

			for (i=0;i < table.length-1; i++) {
				json.append(" { \"fields\": { \"Name\":\""  + table[i] + "\" }},").toString();
			}
			json.append(" { \"fields\": { \"Name\":\""  + table[i] + "\"}}").toString();
			json.append("]}");
			
			String jsonString = json.toString() ;

			HttpResponse response;

			// add json header
			HttpRequest request = HttpRequest.newBuilder()
							.POST(HttpRequest.BodyPublishers.ofString(jsonString))
							.uri(URI.create(tablename))
							.setHeader("User-Agent", "Java 11 HttpClient Bot") // add request header
							.header("Content-Type", "application/json")
							.build();
			response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
			System.out.println(response);
			System.out.println(response.body());		
	}    
	
	public int[] GetTable(String nametable) throws IOException, InterruptedException {
		HttpRequest request = HttpRequest.newBuilder()
				.GET() 
		        .uri(URI.create(nametable))
		        .build();
		
		HttpResponse<String> reponse = httpClient.send(request,HttpResponse.BodyHandlers.ofString());
		System.out.println(reponse.statusCode());
		//System.out.println(reponse.body());
		
		
		int[] tab = new int[10]; 
		Pattern pattern = Pattern.compile("\"Name\":\"(.+?)\"");
	    Matcher matcher = pattern.matcher(reponse.body());

        int i = 0;
	    while (matcher.find()) {
	         //System.out.println(matcher.group(1));  
	         tab[i] = Integer.valueOf(matcher.group(1));
             i++;         
	    }
	    
	   
	    return tab;
		}
	}

