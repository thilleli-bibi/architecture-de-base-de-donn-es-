
/**
 * TP n°:4
 * 
 * Titre du TP :block nestedloop join
 *
 * Date : 19/11/2020
 * 
 * Nom  : Bibi
 * Prenom : Thilleli
 *
 * email : thillelibibi@gmail.com
 * 
 * Remarques : binome : lydia khemsine 
 *            email : lydiakhemsine@outlook.com
 *            
 *            lien vers airtable : https://airtable.com/shrVJ85vp083bMJVv
 */
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.Collections;


public class TablesandBlocks {
	public static int TAILLE_BUF=10;
	public static airTable airtable = new airTable();  

public static ArrayList<String> create_relation(int nbr_lignesR) {
	String[] relation = new String[nbr_lignesR];
	ArrayList<String> r_prime = new ArrayList<String>();
	
	for (char i = 'A'; i < 'Z'; i++) {
		String s = "";
		for (char j = 'A'; j < 'E'; j++) {
			s = s + i + j;
			r_prime.add(s);
			s = "";
		}
	}
	Collections.shuffle(r_prime);
	//System.out.println( r_prime.get(0));
	
return r_prime;

}
public static int[] make_block(ArrayList<String> liste,int index1,int index2) {//String blocname
	int j=0;
	int result[] = new int[10];
	for (int i=index1;i<=index2;i++)
	{
		result[j] = ((int)liste.get(i).charAt(0))*100 + (int)liste.get(i).charAt(1) ;
		  j++;		
	}
	
	return result;
}

public static void all_blocks(ArrayList<String> table,int nbrblocks,String[] blocknames) throws IOException, InterruptedException
{
	int i = 0;int j=9;
	 
	for (int k = 0; k < nbrblocks; k++) {
		int a[] = make_block(table,i,j);
		airtable.block_to_airtable(a,blocknames[k]);
		i+=10;  
		if (k == nbrblocks-2) 
			j+=6;
		else 
		j+=10;		
	}
}


public static void main(String[] args) throws IOException, InterruptedException {
	ArrayList<String> TableR = create_relation(96);
	ArrayList<String> TableS = create_relation(45);
	
	System.out.println("R:  " + TableR);
	System.out.println("S:  " + TableS);
	System.out.println("\n");
	
	String r[] = new String[10];
	r[0] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B00?api_key=keydp37FSYLbFLCVq";
	r[1] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B01?api_key=keydp37FSYLbFLCVq";
	r[2] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B02?api_key=keydp37FSYLbFLCVq";
	r[3] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B03?api_key=keydp37FSYLbFLCVq";
	r[4] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B04?api_key=keydp37FSYLbFLCVq";
	r[5] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B05?api_key=keydp37FSYLbFLCVq";
	r[6] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B06?api_key=keydp37FSYLbFLCVq";
	r[7] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B07?api_key=keydp37FSYLbFLCVq";
	r[8] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B08?api_key=keydp37FSYLbFLCVq";
	r[9] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B09?api_key=keydp37FSYLbFLCVq";

	//TableR's blocks
   all_blocks(TableR,10,r);
   
   String s[] = new String[5];
	s[0] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B10?api_key=keydp37FSYLbFLCVq";
	s[1] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B11?api_key=keydp37FSYLbFLCVq";
	s[2] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B12?api_key=keydp37FSYLbFLCVq";
	s[3] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B13?api_key=keydp37FSYLbFLCVq";
	s[4] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B14?api_key=keydp37FSYLbFLCVq";
   //TableS's bloks
	all_blocks(TableS,5,s);
	 
	 //table descriptor
	 String[] RBlocks = {"B00","B01","B02","B03","B04","B05","B06","B07","B08","B09"};
	 String[] SBlocks = {"B10","B11","B12","B13","B14"};
	 
	 airtable.tabledescriptor(RBlocks,"https://api.airtable.com/v0/appU81OJrhTRidAyh/RTable?api_key=keydp37FSYLbFLCVq");
	 airtable.tabledescriptor(SBlocks,"https://api.airtable.com/v0/appU81OJrhTRidAyh/STable?api_key=keydp37FSYLbFLCVq");

	
}
}







