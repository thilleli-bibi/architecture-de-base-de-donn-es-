/**
 * TP n°:4
 * 
 * Titre du TP :block nestedloop join
 *
 * Date : 19/11/2020
 * 
 * Nom  : Bibi
 * Prenom : Thilleli
 *
 * email : thillelibibi@gmail.com
 * 
 * Remarques : binome : lydia khemsine 
 *            email : lydiakhemsine@outlook.com
 * 
 * lien vers airtable : https://airtable.com/shrVJ85vp083bMJVv 
 */
import java.io.IOException;

public class NestedLoop {

	//charger s et r (les files descriptors)
	public static airTable airtable = new airTable(); 
	
	public static void nestedloop() throws IOException, InterruptedException {
		String Urir[] = new String[10];
		Urir[0] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B00?api_key=keydp37FSYLbFLCVq";
		Urir[1] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B01?api_key=keydp37FSYLbFLCVq";
		Urir[2] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B02?api_key=keydp37FSYLbFLCVq";
		Urir[3] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B03?api_key=keydp37FSYLbFLCVq";
		Urir[4] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B04?api_key=keydp37FSYLbFLCVq";
		Urir[5] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B05?api_key=keydp37FSYLbFLCVq";
		Urir[6] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B06?api_key=keydp37FSYLbFLCVq";
		Urir[7] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B07?api_key=keydp37FSYLbFLCVq";
		Urir[8] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B08?api_key=keydp37FSYLbFLCVq";
		Urir[9] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B09?api_key=keydp37FSYLbFLCVq";
		
		 String Uris[] = new String[5];
		 Uris[0] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B10?api_key=keydp37FSYLbFLCVq";
		 Uris[1] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B11?api_key=keydp37FSYLbFLCVq";
		 Uris[2] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B12?api_key=keydp37FSYLbFLCVq";
		 Uris[3] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B13?api_key=keydp37FSYLbFLCVq";
		 Uris[4] = "https://api.airtable.com/v0/appU81OJrhTRidAyh/B14?api_key=keydp37FSYLbFLCVq";
		 
		 int lenr=0;
		 int lens=0;
		 
		 int[] Blockr,Blocks ; //tableau intermidiare pour charger les blocks
		 int[] result1 = new int[10];
		 int[] result2 = new int[10];
		 int[] result3 = new int[10];
		 int[] result4 = new int[10];


		 int k1 =0; //parcourir result
		 int k2 =0;
		 int k3=0;
		 int k4=0;
		 while(lenr<Urir.length){
			 //charger un block
			 Blockr = airtable.GetTable(Urir[lenr]);
			 lens = 0;
			 while(lens<Uris.length) {
				 Blocks = airtable.GetTable(Uris[lens]);
				 //nestedloop
				 int i=0;int j ;
				 while(i<Blockr.length) { 
					 j=0;
					 while(j<Blocks.length) {
						 if (Blockr[i]==Blocks[j] && Blockr[i]!=0 ) {
							 if (k1<10) {
							  result1[k1] = Blockr[i];
							  k1++;
							 }
							 else if (k2<10) {
								 result2[k2] = Blockr[i];
								  k2++;
								 }
							 else if (k3<10) {
								 result3[k3] = Blockr[i];
								  k3++;
								 }
							 else if (k4<10) {
								 result4[k4] = Blockr[i];
								  k4++;							 }
							 }
						 j++;
						 }
					 i++;
					 }
				 lens++; 
				 }
						 
			lenr++; 
		 }
	 if (k1!=0)
	 {   airtable.block_to_airtable(result1, "https://api.airtable.com/v0/appU81OJrhTRidAyh/RS1?api_key=keydp37FSYLbFLCVq");
		 for(int i=0;i<k1;i++)
			 System.out.println("elmnt" + i +  "  :  " + result1[i]);
	 }
	 if (k2!=0)
	 {  airtable.block_to_airtable(result2, "https://api.airtable.com/v0/appU81OJrhTRidAyh/RS2?api_key=keydp37FSYLbFLCVq");
		 for(int i=0;i<k2;i++)
			 System.out.println("elmnt" + i +  "  :  " + result2[i]);
	 }
	 if (k3!=0)
	 {  airtable.block_to_airtable(result3, "https://api.airtable.com/v0/appU81OJrhTRidAyh/RS3?api_key=keydp37FSYLbFLCVq");
		 for(int i=0;i<k3;i++)
			 System.out.println("elmnt" + i +  "  :  " + result3[i]);
	 }
	 if (k4!=0)
	 {  airtable.block_to_airtable(result4, "https://api.airtable.com/v0/appU81OJrhTRidAyh/RS4?api_key=keydp37FSYLbFLCVq");
		 for(int i=0;i<k4;i++)
			 System.out.println("elmnt" + i +  "  :  " + result4[i]);
	 }	
	}	   
	

public static void main (String[] args) throws IOException, InterruptedException {
	NestedLoop n = new NestedLoop();
	n.nestedloop(); 
}    
}
